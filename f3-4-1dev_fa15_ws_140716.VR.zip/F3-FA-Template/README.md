# F3-Folk ARPS Mission-making Template #

## Changes from default F3 ##

* Wolfenswan's function library (ws_fnc) integrated
* Folk ARPS logo.jpg file included
* F3 features pre-enabled:
  * Name Tags
  * Automatic Body Removal
  * Safe Start default set to 1 minute
  * Set AI Skill for all factions - Missionmakers can remove the cases they do not need
  * Pre-configured endings 1 -3 with generic titles and texts

## Versions ##
* F3 3-4-0
* ws_fnc 05/07/2015