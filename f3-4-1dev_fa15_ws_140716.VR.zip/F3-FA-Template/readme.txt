MISSION README
==============

Mission: [ Insert name of mission ]
Version: [ Insert version here, format: N-N-N ]
Developer(s): [ Insert your name(s) here. ]
Description: [ Insert short mission description here ]



README CONTENTS
===============

01. VERSION HISTORY
02. COPYRIGHT STATEMENT
03. TERMS OF USE
04. LEGAL DISCLAIMER
05. INSTALLATION
06. REQUIRED ADDONS
07. NOTES
08. CHANGE HISTORY



01. VERSION HISTORY
===================

Version | Date | Notes

[ Insert version, format: N-N-N ] | [ Insert date, format: DD MM CCYY ] | [ Insert short note here. ]



02. COPYRIGHT STATEMENT
=======================

This mission is (c)[ CCYY ] [ Insert your name(s) here. ]. All rights reserved.



03. TERMS OF USE
================

This mission (hereafter 'Software') contains files to be used in the PC simulator ArmA 3. To use the Software you must agree to the following conditions of use:

1. [ Insert your name(s) here. ] (hereafter 'The Author(s)') grant to you a personal, non-exclusive license to use the Software.

2. The commercial exploitation of the Software without written permission from The Author(s) is expressly prohibited.



04. LEGAL DISCLAIMER
====================

The Software is distributed without any warranty; without even the implied warranty of merchantability or fitness for a particular purpose. The Software is not an official addon or tool. Use of the Software (in whole or in part) is entirely at your own risk.



05. INSTALLATION
================

To begin using the Software:

1. Move the file [ Insert name of your mission file here. ] into the following directory (assuming you have the Steam version of ArmA 3):

C:\Program Files (x86)\Steam\steamapps\common\Arma 3\MPMissions



06. REQUIRED ADDONS
===================

To play this mission the following addons are required:

[ Insert name of addon ] - [URL for downloadable copy of the addon ]
[ Insert name of addon ] - [URL for downloadable copy of the addon ]
[ Insert name of addon ] - [URL for downloadable copy of the addon ]


07. NOTES
=========

[ Insert your notes here. ]



08. CHANGE HISTORY
==================

Version | Date

[ Insert version, format: N-N-N ] | [ Insert date, format: DD MM CCYY ]
[ Insert change #1 here. ]
[ Insert change #2 here. ]