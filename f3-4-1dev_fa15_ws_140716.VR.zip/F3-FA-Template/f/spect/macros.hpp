// F3 - Spectator Script
// Credits: Please see the F3 online manual (http://www.ferstaberinde.com/f3/en/)
// ====================================================================================
// Quick defines to make it less annoying.
#define F_CAM_DISPLAY 9228
#define F_CAM_HELPFRAME 1300
#define F_CAM_HELPBACK 1305
#define F_CAM_MOUSEHANDLER 123
#define F_CAM_UNITLIST 2100
#define F_CAM_MODESCOMBO 2101
#define F_CAM_SPECTEXT 1000
#define F_CAM_SPECHELP 1310
#define F_CAM_HELPCANCEL 1315
#define F_CAM_MINIMAP 1350
#define F_CAM_FULLMAP 1360
#define F_CAM_BUTTIONFILTER 2111
#define F_CAM_BUTTIONTAGS 2112
#define F_CAM_BUTTIONTAGSNAME 2113
#define F_CAM_BUTTIONFIRSTPERSON 2114
#define F_CAM_DIVIDER 4302